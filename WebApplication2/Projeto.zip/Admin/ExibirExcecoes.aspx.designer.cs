﻿//------------------------------------------------------------------------------
// <gerado automaticamente>
//     Este código foi gerado por uma ferramenta.
//
//     As alterações ao arquivo poderão causar comportamento incorreto e serão perdidas se
//     o código for recriado
// </gerado automaticamente>
//------------------------------------------------------------------------------

namespace WebApplication2.Admin
{


   public partial class ExibirExcecoes
   {

      /// <summary>
      /// Controle Excecoes.
      /// </summary>
      /// <remarks>
      /// Campo gerado automaticamente.
      /// Modificar a declaração do campo de movimento do arquivo de designer para o arquivo code-behind.
      /// </remarks>
      protected global::System.Web.UI.WebControls.Label Excecoes;

      /// <summary>
      /// Controle Excluir.
      /// </summary>
      /// <remarks>
      /// Campo gerado automaticamente.
      /// Modificar a declaração do campo de movimento do arquivo de designer para o arquivo code-behind.
      /// </remarks>
      protected global::System.Web.UI.WebControls.Button Excluir;
   }
}
