﻿//------------------------------------------------------------------------------
// <gerado automaticamente>
//     Este código foi gerado por uma ferramenta.
//
//     As alterações ao arquivo poderão causar comportamento incorreto e serão perdidas se
//     o código for recriado
// </gerado automaticamente>
//------------------------------------------------------------------------------

namespace WebApplication2.Admin
{


   public partial class Usuarios
   {

      /// <summary>
      /// Controle Codigo.
      /// </summary>
      /// <remarks>
      /// Campo gerado automaticamente.
      /// Modificar a declaração do campo de movimento do arquivo de designer para o arquivo code-behind.
      /// </remarks>
      protected global::System.Web.UI.WebControls.Label Codigo;

      /// <summary>
      /// Controle Erro.
      /// </summary>
      /// <remarks>
      /// Campo gerado automaticamente.
      /// Modificar a declaração do campo de movimento do arquivo de designer para o arquivo code-behind.
      /// </remarks>
      protected global::System.Web.UI.WebControls.Label Erro;

      /// <summary>
      /// Controle NomeCompleto.
      /// </summary>
      /// <remarks>
      /// Campo gerado automaticamente.
      /// Modificar a declaração do campo de movimento do arquivo de designer para o arquivo code-behind.
      /// </remarks>
      protected global::System.Web.UI.WebControls.TextBox NomeCompleto;

      /// <summary>
      /// Controle Email.
      /// </summary>
      /// <remarks>
      /// Campo gerado automaticamente.
      /// Modificar a declaração do campo de movimento do arquivo de designer para o arquivo code-behind.
      /// </remarks>
      protected global::System.Web.UI.WebControls.TextBox Email;

      /// <summary>
      /// Controle NomeAcesso.
      /// </summary>
      /// <remarks>
      /// Campo gerado automaticamente.
      /// Modificar a declaração do campo de movimento do arquivo de designer para o arquivo code-behind.
      /// </remarks>
      protected global::System.Web.UI.WebControls.TextBox NomeAcesso;

      /// <summary>
      /// Controle Senha.
      /// </summary>
      /// <remarks>
      /// Campo gerado automaticamente.
      /// Modificar a declaração do campo de movimento do arquivo de designer para o arquivo code-behind.
      /// </remarks>
      protected global::System.Web.UI.WebControls.TextBox Senha;

      /// <summary>
      /// Controle Anotacoes.
      /// </summary>
      /// <remarks>
      /// Campo gerado automaticamente.
      /// Modificar a declaração do campo de movimento do arquivo de designer para o arquivo code-behind.
      /// </remarks>
      protected global::System.Web.UI.WebControls.TextBox Anotacoes;

      /// <summary>
      /// Controle Salvar.
      /// </summary>
      /// <remarks>
      /// Campo gerado automaticamente.
      /// Modificar a declaração do campo de movimento do arquivo de designer para o arquivo code-behind.
      /// </remarks>
      protected global::System.Web.UI.WebControls.Button Salvar;

      /// <summary>
      /// Controle Excluir.
      /// </summary>
      /// <remarks>
      /// Campo gerado automaticamente.
      /// Modificar a declaração do campo de movimento do arquivo de designer para o arquivo code-behind.
      /// </remarks>
      protected global::System.Web.UI.WebControls.Button Excluir;

      /// <summary>
      /// Controle Mensagem.
      /// </summary>
      /// <remarks>
      /// Campo gerado automaticamente.
      /// Modificar a declaração do campo de movimento do arquivo de designer para o arquivo code-behind.
      /// </remarks>
      protected global::System.Web.UI.WebControls.Label Mensagem;

      /// <summary>
      /// Controle BuscarNome.
      /// </summary>
      /// <remarks>
      /// Campo gerado automaticamente.
      /// Modificar a declaração do campo de movimento do arquivo de designer para o arquivo code-behind.
      /// </remarks>
      protected global::System.Web.UI.WebControls.TextBox BuscarNome;

      /// <summary>
      /// Controle Buscar.
      /// </summary>
      /// <remarks>
      /// Campo gerado automaticamente.
      /// Modificar a declaração do campo de movimento do arquivo de designer para o arquivo code-behind.
      /// </remarks>
      protected global::System.Web.UI.WebControls.Button Buscar;

      /// <summary>
      /// Controle Cancelar.
      /// </summary>
      /// <remarks>
      /// Campo gerado automaticamente.
      /// Modificar a declaração do campo de movimento do arquivo de designer para o arquivo code-behind.
      /// </remarks>
      protected global::System.Web.UI.WebControls.Button Cancelar;

      /// <summary>
      /// Controle PanelUsuarios.
      /// </summary>
      /// <remarks>
      /// Campo gerado automaticamente.
      /// Modificar a declaração do campo de movimento do arquivo de designer para o arquivo code-behind.
      /// </remarks>
      protected global::System.Web.UI.WebControls.Panel PanelUsuarios;

      /// <summary>
      /// Controle ViewUsuarios.
      /// </summary>
      /// <remarks>
      /// Campo gerado automaticamente.
      /// Modificar a declaração do campo de movimento do arquivo de designer para o arquivo code-behind.
      /// </remarks>
      protected global::System.Web.UI.WebControls.GridView ViewUsuarios;
   }
}
